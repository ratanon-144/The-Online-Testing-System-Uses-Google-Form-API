const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const { User, Instructor, Course, Student, CourseEnrollment, TestBank, TestSet, Question, Answer,sequelize } = require("./models/dataset4");
const {Sequelize,QueryTypes } = require("sequelize");
const formidable = require("formidable");
const path = require("path"); 
const Op = Sequelize.Op;
const constants = require("./constant");
const jwt = require("./jwt");


router.post("/login", async (req, res) => {
  try {
    const user = await User.findOne({ where: { username: req.body.username } });
    if (!user) {
      return res.json({ result: constants.kResultNok, message: "Invalid username or password" });
    }
    console.log(user.level);
    const passwordIsValid = bcrypt.compareSync(req.body.password, user.password);
    if (!passwordIsValid) {
      return res.json({ result: constants.kResultNok, message: "Invalid username or password" });
    }
    console.log(passwordIsValid);
    let profile = {};
    if (user.level === "instructor") {
      const instructor = await Instructor.findOne({ where: { username: user.username } });

      profile = {
        instructor_name: instructor.instructor_name,
        username: instructor.username,
        level: user.level
      };
    } else if (user.level === "student") {
      const student = await Student.findOne({ where: { username: user.username } });
      console.log(student);
      profile = {
        student_name: student.student_name,
        username: student.username,
        level: user.level
      };
    }

    res.json({ result: constants.kResultOk, user: { ...profile } });
  } catch (error) {
    res.json({ result: constants.kResultNok, message: JSON.stringify(error) });
  }
});

router.post("/register", async (req, res) => {
  try {
    req.body.password = bcrypt.hashSync(req.body.password, 8);
    const fullname = `${req.body.title} ${req.body.firstname} ${req.body.lastname}`;
    let user = await User.create(req.body);
    let profile = {};
    if (req.body.level === "instructor") {
      const instructor = await Instructor.create({
        instructor_name: fullname,
        username: user.username
      });
      profile = {
        instructor_name: instructor.instructor_name,
        username: instructor.username,
        message: "Teacher created successfully"
      };
    } else if (req.body.level === "student") {
      const student = await Student.create({
        student_name: fullname,
        username: user.username
      });
      profile = {
        student_name: student.student_name,
        username: student.username,
        message: "Student created successfully"
      };
    } else {
      res.json({ result: constants.kResultNok, message: "Invalid user level" });
    }
    res.json({ result: constants.kResultOk, user: { ...profile } });
  } catch (error) {
    res.json({ result: constants.kResultNok, message: JSON.stringify(error) });
  }
}); 


 

// Get course all
router.get("/course/:id", async (req, res) => {
  try {
    const teacher = await Teacher.findOne({ where: { username: req.params.id  } });
    const newClass = await teacher.createClass({ class_name: "Mathematics 101" });
    console.log(`Class created successfully! Class name: ${newClass.class_name}`);
  } catch (error) {
    console.error("Error creating class:", error);
  }
});
 

/// add ClassEnrollment เพื่มนักศึกษาเข้าไปไหน class
router.post("/course/:id", async (req, res) => {
  try{ 
    const {class_id,student_id} = req.body;
   const checkid = await ClassEnrollment.findOne({ where: { class_id: class_id } });
  if(checkid != null){
    res.json({me:"Nok", message: JSON.stringify(checkid)});
  }else{ 
     try {
      const result = ClassEnrollment.create({
        class_id: class_id,
        student_id: student_id
      });
      res.json({result});
    } catch (error) {
      res.json({ message: JSON.stringify(error) });
    }
  }
  }catch{
    res.json("eer")
  } 
});

/// แก้ไข course   
router.put('/course/:id', async (req, res) => {
  try {
    const updatedRows = await Class.update(req.body, { where: { class_id: req.params.id } });
    console.log(updatedRows);
    if (updatedRows[0] === 0) {
      res.status(404).send("Class not found");
    } else {
      res.status(200).send("Class updated successfully");
    }
  } catch (error) {
    console.error(error);
    res.status(500).send("Server error");
  }
});
 
//### ลบ course เฉพาะที่อาจารย์ สอน
router.delete('/course/:id', async (req, res) => {
  try { 
    const deletedRows = await Class.destroy({ where: { class_id: req.params.id } });
    if (deletedRows === 0) {
      res.status(404).send("Class not found");
    } else {
      res.json({ result: "OK", message: JSON.stringify(deletedRows) });
    }
  } catch (error) { 
    res.status(500).send("Server error");
  }
});




router.get("/dropall", async (req, res) => {
  try {
   // await Sequelize.drop();
   await sequelize.drop();
    res.status(200).json({ message: "All tables dropped successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "An error occurred while dropping tables" });
  }
});

router.get("/creattable", async (req, res) => {
  try {
   // await Sequelize.drop();
   await sequelize.sync({ force: true });
    res.status(200).json({ message: "All tables dropped successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "An error occurred while dropping tables" });
  }
});
module.exports = router;
