const { Sequelize, DataTypes } = require("sequelize");
const sequelize = require("../db_instance");

const User = sequelize.define(
  "users",
  {
    // attributes
    username: {
      type: Sequelize.STRING,
      allowNull: false,
      primaryKey: true
    },
    password: {
      type: Sequelize.STRING,
      allowNull: false
    },
    level: {
      type: Sequelize.STRING,
      defaultValue: "normal"
    },
    email: {
      type: Sequelize.STRING,
      allowNull: false
    }
  }
);

const Teacher = sequelize.define("teachers", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  teacher_name: DataTypes.STRING
});

const Student = sequelize.define("students", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  student_name: DataTypes.STRING
});

const Class = sequelize.define("classes", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  class_name: DataTypes.STRING
});

const ClassEnrollment = sequelize.define("class_enrollment", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  classId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "classes",
      key: "id"
    }
  },
  studentId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "students",
      key: "id"
    }
  }
});

User.hasOne(Teacher, {
  foreignKey: "username",
  scope: { level: "teacher" }
});
Teacher.belongsTo(User, {
  foreignKey: "username",
  scope: { level: "teacher" }
});

User.hasOne(Student, {
  foreignKey: "username",
  scope: { level: "student" }
});
Student.belongsTo(User, {
  foreignKey: "username",
  scope: { level: "student" }
});

Teacher.hasMany(Class, { foreignKey: "teacherId" });
Class.belongsTo(Teacher, { foreignKey: "teacherId" });

Class.belongsToMany(Student, {
  through: ClassEnrollment,
  foreignKey: "classId"
});
Student.belongsToMany(Class, {
  through: ClassEnrollment,
  foreignKey: "studentId"
});

(async () => {
  await sequelize.sync({ force: false });
})();

module.exports = {
  User,
  Teacher,
  Class,
  Student,
  ClassEnrollment
};
