const { Sequelize, DataTypes } = require("sequelize");
const sequelize = require("../db_instance");

const User = sequelize.define(
  "users",
  {
    // attributes
    username: {
      type: Sequelize.STRING,
      allowNull: false,
      primaryKey: true
    },
    password: {
      type: Sequelize.STRING,
      allowNull: false
    },
    level: {
      type: Sequelize.STRING,
      defaultValue: "normal"
    },
    email: {
      type: Sequelize.STRING,
      allowNull: false
    }
  }
);

const Instructor = sequelize.define("instructors", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  instructor_name: DataTypes.STRING
});

const Student = sequelize.define("students", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  student_name: DataTypes.STRING
});

const Course = sequelize.define("courses", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  course_name: DataTypes.STRING,
  sec: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 1
  }
});

const CourseEnrollment = sequelize.define("course_enrollment", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  courseId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "courses",
      key: "id"
    }
  },
  studentId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "students",
      key: "id"
    }
  },
  sec: {
    type: DataTypes.INTEGER,
    allowNull: false,
    defaultValue: 1
  }
});

User.hasOne(Instructor, {
  foreignKey: "username",
  scope: { level: "instructor" }
});
Instructor.belongsTo(User, {
  foreignKey: "username",
  scope: { level: "instructor" }
});

User.hasOne(Student, {
  foreignKey: "username",
  scope: { level: "student" }
});
Student.belongsTo(User, {
  foreignKey: "username",
  scope: { level: "student" }
});

Instructor.hasMany(Course, { foreignKey: "instructorId" });
Course.belongsTo(Instructor, { foreignKey: "instructorId" });

Course.belongsToMany(Student, {
  through: CourseEnrollment,
  foreignKey: "courseId"
});
Student.belongsToMany(Course, {
  through: CourseEnrollment,
  foreignKey: "studentId"
});

(async () => {
  await sequelize.sync({ force: false });
})();

module.exports = {
  User,
  Instructor,
  Course,
  Student,
  CourseEnrollment
};
