const { Sequelize, DataTypes } = require("sequelize");
const sequelize = require("../db_instance");

const User = sequelize.define(
    "users",
    {
      // attributes
      username: {
        type: Sequelize.STRING,
        allowNull: false,
        primaryKey: true
      },
      password: {
        type: Sequelize.STRING,
        allowNull: false
      },
      level: {
        type: Sequelize.STRING,
        defaultValue: "normal"
      },
      email: {
        type: Sequelize.STRING,
        allowNull: false
      }
    }
  );

const Instructor = sequelize.define("instructors", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  instructor_name: DataTypes.STRING
});

const Student = sequelize.define("students", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  student_name: DataTypes.STRING
});

const Course = sequelize.define("courses", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  course_name: DataTypes.STRING,
  sec: {
    type: DataTypes.INTEGER,
    defaultValue: 1
  }
});

const CourseEnrollment = sequelize.define("course_enrollment", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  courseId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "courses",
      key: "id"
    }
  },
  studentId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: "students",
      key: "id"
    }
  }
});

const TestBank = sequelize.define("test_banks", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  bank_name: DataTypes.STRING
});

const TestSet = sequelize.define("test_sets", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  set_name: DataTypes.STRING
});

const Question = sequelize.define("questions", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  question_text: DataTypes.STRING
});

const Answer = sequelize.define("answers", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  answer_text: DataTypes.STRING
});
const CourseTestBank = sequelize.define("course_test_banks", {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    sec: DataTypes.INTEGER,
  });
  
  Course.belongsToMany(TestBank, { through: CourseTestBank });
  TestBank.belongsToMany(Course, { through: CourseTestBank });
  
  TestBank.hasMany(TestSet, { foreignKey: "testBankId" });
  TestSet.belongsTo(TestBank, { foreignKey: "testBankId" });


TestSet.hasMany(Question, { foreignKey: "testSetId" });
Question.belongsTo(TestSet, { foreignKey: "testSetId" });

Question.hasMany(Answer, { foreignKey: "questionId" });
Answer.belongsTo(Question, { foreignKey: "questionId" });

Instructor.hasMany(Course, { foreignKey: "instructorId" });
Course.belongsTo(Instructor, { foreignKey: "instructorId" });

Course.belongsToMany(Student, {
  through: CourseEnrollment,
  foreignKey: "courseId"
});
Student.belongsToMany(Course, {
  through: CourseEnrollment,
  foreignKey: "studentId"
});

(async () => {
  await sequelize.sync({ force: false });
})();

module.exports = {
  User,
  Instructor,
  Course,
  Student,
  CourseEnrollment,
  TestBank,
  TestSet,
  Question,
  Answer,sequelize
};
