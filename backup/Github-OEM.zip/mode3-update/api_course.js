const express = require("express");
const router = express.Router();
const {User,Teacher,Class,Student,ClassEnrollment,} = require("./models/dataset2");
const {Sequelize,QueryTypes } = require("sequelize");
const formidable = require("formidable");
const path = require("path"); 
const Op = Sequelize.Op;
const jwt = require("./jwt");


/// add ClassEnrollment เพื่มนักศึกษาเข้าไปไหน class
router.post("/classenrollment", async (req, res) => {
  try{ 
    const {class_id,student_id} = req.body;
   const checkid = await ClassEnrollment.findOne({ where: { class_id: class_id } });
  if(checkid != null){
    res.json({me:"Nok", message: JSON.stringify(checkid)});
  }else{ 
     try {
      const result = ClassEnrollment.create({
        class_id: class_id,
        student_id: student_id
      });
      res.json({result});
    } catch (error) {
      res.json({ message: JSON.stringify(error) });
    }
  }
  }catch{
    res.json("eer")
  } 
});
/// add ClassEnrollment เพื่มนักศึกษาเข้าไปไหน class arry limit 3 use
router.post("/classenrollments", async (req, res) => {
  try{ 
    const {classes} = req.body;
    if(classes == null){
     res.json({me:"Nok", message: JSON.stringify("not classes type arry ")});
  }else{ 
     try {
      const result = ClassEnrollment.bulkCreate(classes);
      res.json({result});
    } catch (error) {
      res.json({ message: JSON.stringify(error) });
    }
  //  res.json("OK")
  }
  }catch{
    res.json("eer")
  } 
});
// Get course all
router.get("/course", async (req, res) => {
  try {
    const results = await Class.findAll()
  
    if (results != null) {
      res.json(results);
    } else {
      res.json({ message: "Notfi" });
    }
  } catch (error) {
    res.json({  message: "notfil" });
  }
});

// แสดงรายชื่อนักศึกษาที่อยู่ใน class
router.get("/courses/:id", async (req, res) => {
  try { 
    const results = await Class.findAll({
      attributes: ['class_name'],
      include: [
        {
          model: Student,
          attributes: ['student_id', 'student_name'],
          through: {
            attributes: []
          }
        }
      ],
      where: {
        teacher_id: req.params.id
      }
    });
    if (results != null) {
      res.json(results);
    } else {
      res.json({ message: "Notfi" });
    }
  } catch (error) {
    res.json({  message: "notfil" });
  }
});

// แสดงรายชื่ออาจารย์ที่อยู่ใน class
router.get("/coursei/:id", async (req, res) => {
  try {
    const results = await Class.findAll({
      attributes: ['class_name'],
      include: [
        {
          model: Teacher,
          attributes: ['teacher_name']
        },
        {
          model: Student,
          attributes: [],
          where: {
            student_id: req.params.id
          }
        }
      ]
    });
    
    if (results != null) {
      res.json(results);
    } else {
      res.json({ message: "Notfi" });
    }
  } catch (error) {
    res.json({  message: "notfil" });
  }
});


// แสดงรายการ course ที่อาจารย์ สอนอยู่ #GET
router.get("/course/:id", async (req, res) => {
  try { 
    const results = await Class.findAll({
      where: { teacher_id: req.params.id },
    });
    console.log(results);
    if (results != null) {
      res.json(results);
    } else {
      res.json({ message: "Notfi" });
    }
  } catch (error) {
    res.json({  message: "notfil1" });
  }
});

//add อาจารย์สร้าง course 
router.post("/course", async (req, res) => {
  try{ 
    const {class_id,class_name,teacher_id} = req.body;
   const checkid = await Class.findOne({ where: { class_id: class_id } });
  if(checkid != null){
    res.json({me:"Nok", message: JSON.stringify(checkid)});
  }else{ 
     try {
      const result = Class.create({
        class_id: class_id,
        class_name: class_name,
        teacher_id:teacher_id
      });
      res.json({result});
    } catch (error) {
      res.json({ message: JSON.stringify(error) });
    }
  }
  }catch{
    res.status(500).send("Server error");
  } 
});


/// แก้ไข course   
router.put('/course/:id', async (req, res) => {
  try {
    const updatedRows = await Class.update(req.body, { where: { class_id: req.params.id } });
    console.log(updatedRows);
    if (updatedRows[0] === 0) {
      res.status(404).send("Class not found");
    } else {
      res.status(200).send("Class updated successfully");
    }
  } catch (error) {
    console.error(error);
    res.status(500).send("Server error");
  }
});
 
//### ลบ course เฉพาะที่อาจารย์ สอน
router.delete('/course/:id', async (req, res) => {
  try { 
    const deletedRows = await Class.destroy({ where: { class_id: req.params.id } });
    if (deletedRows === 0) {
      res.status(404).send("Class not found");
    } else {
      res.json({ result: "OK", message: JSON.stringify(deletedRows) });
    }
  } catch (error) { 
    res.status(500).send("Server error");
  }
});

module.exports = router;
