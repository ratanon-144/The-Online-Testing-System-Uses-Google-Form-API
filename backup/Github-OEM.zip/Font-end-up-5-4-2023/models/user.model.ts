export interface UserData {
  id?:string;
  username?: string;
  level?: string;
  email?: string;
  title?:string;
  firstname?: string;
  lastname?: string;
  fullname?: string;
  image?: string;
  token?: string;
}
