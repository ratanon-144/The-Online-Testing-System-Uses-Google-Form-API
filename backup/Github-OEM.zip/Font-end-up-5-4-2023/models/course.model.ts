export interface CourseData {
  id:         number;
  class_id:   number;
  class_name: string;
  createdAt:  Date;
  updatedAt:  Date;
  teacher_id: number;
  teacher:    Teacher;
}

export interface Teacher {
  teacher_id:   number;
  teacher_name: string;
  createdAt:    Date;
  updatedAt:    Date;
  username:     string;
}
