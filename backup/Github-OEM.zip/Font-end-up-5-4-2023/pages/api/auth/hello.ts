// Next.js API route support: https://nextjs.org/docs/api-routes/introduction
import type { NextApiRequest, NextApiResponse } from 'next'
type Data = {
    id:number;
    name: string;
    age: number;
    dateCreated: string;
    lastLogin: string;
  }
export default function handler(
    req: NextApiRequest,
    res: NextApiResponse<Data>) {
      let to = [ {
        id: 1,
        name:"AAAAA",
        age: 525,
        dateCreated: "2023-04-05T07:57:56.000Z",
        lastLogin: "2023-04-05T07:57:56.000Z",
      }, {
        id: 2,
        name:"ZXC",
        age: 425,
        dateCreated: "2023-04-05T07:57:56.000Z",
        lastLogin: "2023-04-05T07:57:56.000Z",
      },
      {
        id:3,
        name:"AWDAD",
        age: 125,
        dateCreated: "2023-04-05T07:57:56.000Z",
        lastLogin: "2023-04-05T07:57:56.000Z",
      },{
        id: 4,
        name:"XXXXX",
        age: 225,
        dateCreated: "2023-04-05T07:57:56.000Z",
        lastLogin: "2023-04-05T07:57:56.000Z",
      }
    ]
         res.json(to)
    
  }