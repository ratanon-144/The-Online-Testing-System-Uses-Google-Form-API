import * as React from "react";
import Button from "@mui/material/Button";
import AddIcon from "@mui/icons-material/Add";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/DeleteOutlined";
import SaveIcon from "@mui/icons-material/Save";
import CancelIcon from "@mui/icons-material/Close";
import {GridRowsProp,GridRowModesModel,GridRowModes,DataGrid,GridColumns,GridRowParams,MuiEvent,GridToolbarContainer,GridActionsCellItem,GridEventListener,GridRowId, GridRowModel, useGridApiContext,gridEditRowsStateSelector
} from "@mui/x-data-grid";
import { Card, Stack, Typography ,Box } from "@mui/material";
interface User {
  class_id: number;
  class_name: string;
  createdAt: string;
  updatedAt: string;
  teacher_id: number;
  teacher: Teacher;
}

interface Teacher {
  teacher_id: number;
  teacher_name: string;
  createdAt: string;
  updatedAt: string;
  username: string;
}

async function fetchUsers() {
  const res = await fetch('http://51.79.251.237:8085/api/v2/course/coursel/1');
  const data = await res.json();
  return data;
}

interface Props {}
const Instructor = ({}: Props) => {
  const [rows, setRows] = React.useState([]);
  const [rowModesModel, setRowModesModel] = React.useState<GridRowModesModel>({});

  React.useEffect(() => {
    async function getUsers() {
      const data = await fetchUsers();
      const rows = data.map((user: User) => {
        return {
          id: user.class_id,
          class_id: user.class_id,
          class_name: user.class_name,
          isNew: false
        };
      });
      setRows(rows);
    }

    getUsers();
  }, []);

  const columns: GridColumns = [
    { field: "class_id", type: "number", headerName: "ลำดับ", width: 180, headerClassName: 'super-app-theme--header', editable: true },
    { field: "class_name", type: "string",  headerName: "ชื่อเรื่อง", flex: 1,headerClassName: 'super-app-theme--header', editable: true },
  ];

return (
<Stack spacing={2}>
<Typography text-align='left' variant='h3'>คลังข้อสอบ</Typography>  
 <Card  sx={{ margin: "10",   padding: "30px 25px",    textTransform: "capitalize",    }}> 
        <Stack spacing={2}>
                     <Box  sx={{    height: 600,    width: "100%", "& .super-app-theme--header": {backgroundColor: "#FF9800",color:"#FFF" } }}> 
                    <DataGrid rows={rows}  columns={columns} editMode="row" rowModesModel={rowModesModel}
                 />
                 </Box>
            </Stack>
       </Card>
   </Stack>
  );
}
export default Instructor