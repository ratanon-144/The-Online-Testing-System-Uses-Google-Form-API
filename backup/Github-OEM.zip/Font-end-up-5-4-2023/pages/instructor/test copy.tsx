import { GetStaticProps } from 'next/types';
import { useState, useEffect } from 'react';

interface User {
  class_id: number;
  class_name: string;
  createdAt: string;
  updatedAt: string;
  teacher_id: number;
  teacher: Teacher;
}

interface Teacher {
  teacher_id: number;
  teacher_name: string;
  createdAt: string;
  updatedAt: string;
  username: string;
}

export const getStaticProps: GetStaticProps = async () => {
  const res = await fetch('http://51.79.251.237:8085/api/v2/course/coursel/1');
  const data = await res.json();
  return {
    props: {
      users: data,
    },
    revalidate: 10, // In seconds
  };
};

const Users = ({ users }: { users: User[] | null }) => {
  return (
    <div>
      <p>test</p>
      {users?.map((user) => (
        <div key={user.class_id}>
          <h1>{user.class_name}</h1>
          <p>{user.teacher?.teacher_name}</p>
        </div>
      ))}
    </div>
  );
};

export default Users;
