import React from 'react'

type Props = {}

export default function profile({}: Props) {
  return (
    <div>profile</div>
  )
}