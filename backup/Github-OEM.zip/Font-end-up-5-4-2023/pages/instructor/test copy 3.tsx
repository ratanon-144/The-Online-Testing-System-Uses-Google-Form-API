import Layout from "@/components/Layouts/Layout";
import withAuth from "@/components/withAuth";
import React from "react";
import { useAppDispatch } from "@/store/store";
import { courseSelector, getCourses, deleteCourse } from "@/store/slices/courseSlice";
import { useSelector } from "react-redux";
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import AddIcon from '@mui/icons-material/Add';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/DeleteOutlined';
import SaveIcon from '@mui/icons-material/Save';
import CancelIcon from '@mui/icons-material/Close';
import {  GridRowsProp,GridRowModesModel,GridRowModes,DataGridPro,GridColDef,GridRowParams, MuiEvent, GridToolbarContainer, GridActionsCellItem, GridEventListener, GridRowId, GridRowModel,} from '@mui/x-data-grid-pro';
import { Stack } from "@mui/material";
import { DataGrid, GridCellParams } from "@mui/x-data-grid";

type Props = {};

export const columns: GridColDef[] = [
  { field: "id", headerName: "ID", width: 100 },
  { field: "class_id", headerName: "Class ID", width: 130 },
  { field: "class_name", headerName: "Class Name", width: 200 },
  { field: "createdAt", headerName: "Created At", width: 200 },
  { field: "updatedAt", headerName: "Updated At", width: 200 },
  { field: "teacher", headerName: "Teacher Name", width: 200 },
];
 
  

const Stock = ({}: Props) => {
  const dispatch = useAppDispatch();
  const courseList = useSelector(courseSelector);
  React.useEffect(() => {
    dispatch(getCourses(1));
  }, [dispatch]);
  React.useEffect(() => {
    setRows(courseList);
  }, [courseList]);

  const [rows, setRows] = React.useState(courseList);
  const [rowModesModel, setRowModesModel] = React.useState<GridRowModesModel>({});

  const columns: GridColDef[] = [
   
    { field: 'class_id', headerName: 'Class ID', width: 120 ,headerClassName: 'super-app-theme--header', editable: true},
    { field: 'class_name', headerName: 'Class Name', width: 200 ,headerClassName: 'super-app-theme--header', editable: true },
    { field: 'createdAt', headerName: 'Created At', type: 'date', width: 160 ,headerClassName: 'super-app-theme--header'},
    { field: 'updatedAt', headerName: 'Updated At', type: 'date', flex: 1,headerClassName: 'super-app-theme--header' },
   
  ];
  
   
  return (
    <Layout>
      <div>TEST</div> 
      <Box  sx={{    height: 600,    width: "100%", "& .super-app-theme--header": {backgroundColor: "#FF9800",color:"#FFF" } }}> 
        <DataGrid
          rows={rows ?? []}
          columns={columns}
          getRowId={(row: any) =>  row.class_id }
           
        />
      </Box>
    </Layout>
  );
};

export default withAuth(Stock);