import { useState, useEffect } from 'react'

interface Data{
  id:number;
  email:string;
  first_name:string;
last_name:string;
avatar:string;
}

export default function Profile() {
  const [data, setData] = useState<Data>()
  const [isLoading, setLoading] = useState(false)

  useEffect(() => {
    setLoading(true)
    fetch('http://51.79.251.237:8085/api/v2/course/coursel/1')
      .then((res) => res.json())
      .then((data) => {
        setData(data)
        setLoading(false)
      })
  }, [])

  if (isLoading) return <p>Loading...</p>
  if (!data) return <p>No profile data</p>

  return (
    <div>
      <h1>{data.first_name}</h1>
      <p>{data.last_name}</p>
    </div>
  )
}