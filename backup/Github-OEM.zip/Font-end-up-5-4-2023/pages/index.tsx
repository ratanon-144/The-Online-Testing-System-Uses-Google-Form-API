import withAuth from "@/components/withAuth";
import React from "react";

type Props = {};

const Index = ({}: Props) => {
  return <></>;
};

export default withAuth(Index);
