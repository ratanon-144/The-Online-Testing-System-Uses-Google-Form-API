module.exports = 
{
    kResultOk: 'ok',
    kResultNok: 'nok'
}