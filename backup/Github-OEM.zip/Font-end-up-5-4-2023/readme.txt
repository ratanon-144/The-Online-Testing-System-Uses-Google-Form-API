# create and run project
npx create-next-app@latest cmnext-stock-2022 --typescript
yarn dev 
or 
npm run dev

# vscode extensions
code --install-extension dsznajder.es7-react-js-snippets
code --install-extension vscode-icons-team.vscode-icons
code --install-extension naumovs.color-highlight
code --install-extension esbenp.prettier-vscode
code --install-extension humao.rest-client
code --install-extension riazxrazor.html-to-jsx
code --install-extension christian-kohler.path-intellisense
code --install-extension alexcvzz.vscode-sqlite

# add mui libs
yarn add @emotion/cache @emotion/react @emotion/server @emotion/styled
yarn add @mui/material
yarn add @mui/icons-material

# extra libs 1
yarn add formik formik-material-ui chart.js react-chartjs-2 react-moment moment react-number-format
yarn add @reduxjs/toolkit react-redux axios cookie @react-hook/debounce @mui/x-data-grid react-iframe
yarn add @types/cookie --dev

#extra libs 2
yarn add react-medium-image-zoom

# redux dev tool
https://chrome.google.com/webstore/detail/redux-devtools/lmhkpmbekcpmknklioeibfkpmmfibljd?hl=th

# next api
https://nextjs.org/learn/basics/api-routes/creating-api-routes

  
# chart option
https://www.chartjs.org/docs/latest/general/options.html  