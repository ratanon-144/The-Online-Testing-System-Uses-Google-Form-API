export interface UserData {
  username?: string;
  email?: string;
  title?:string;
  firstname?: string;
  lastname?: string;
  image?: string;
  token?: string;
}
