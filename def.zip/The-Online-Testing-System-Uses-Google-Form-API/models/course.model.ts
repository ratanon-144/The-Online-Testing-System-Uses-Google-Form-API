export interface CourseData {
  id?: number;
  subjectid: string;
  subjectname: string;
  secid?:  string;
  createdAt?: Date;
  updatedAt?: Date;
}
