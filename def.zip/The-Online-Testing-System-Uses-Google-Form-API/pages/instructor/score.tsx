import Layout from '@/components/Layouts/Layout'
import React from 'react'

type Props = {}

export default function score({}: Props) {
  return (
    <Layout>
    <div>score</div>
    </Layout>
  )
}