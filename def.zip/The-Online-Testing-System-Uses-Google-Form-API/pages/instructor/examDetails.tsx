import React from 'react'

type Props = {}

export default function examDetails({}: Props) {
  return (
    <div>examDetails</div>
  )
}