import React from 'react'

type Props = {}

export default function answerHistory({}: Props) {
  return (
    <div>answerHistory</div>
  )
}