import React from 'react'

type Props = {}

export default function question({}: Props) {
  return (
    <div>question</div>
  )
}