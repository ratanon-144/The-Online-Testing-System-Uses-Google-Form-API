/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ["localhost","51.79.251.237"],
  },
};

module.exports = nextConfig;
